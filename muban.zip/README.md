零号病人

入口

https://1012598167.github.io/muban/index.html

点击乱斗，斗 进入游戏



感谢无名杀提供的框架支持。



//百度网盘分流

//数据包 https://pan.baidu.com/s/1CqSyEelJfuMhnPgFGJFWKg 提取码:70yq

//安卓/Windows/iOS客户端 https://pan.baidu.com/s/1NTGyQFpyaAFN6Lhx5AYEWA 提取码:6ea7
